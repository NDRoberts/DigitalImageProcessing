from matplotlib import pyplot as plt

arblegarble = [1, 6, 9, 43, 6, 0, 21, 22, 30, 14, 44, 2]
plt.plot(arblegarble)
plt.ylabel('FUCK SHIT STACK')
plt.show()